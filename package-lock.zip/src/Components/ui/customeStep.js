import React from 'react';
import CustomStepper from './stepper';

const CustopStep = () =>{
    const steps = ['Step 1', 'Step 2', 'Step 3'];
}